package Mycat;

public class App {
    public static void main(String[] args) throws Exception {

        
        Siamaine myPet = new Pet();

        myPet.bark();
        System.out.println(myPet.mouth);
        System.out.println(myPet.eyeColor);
    }
}