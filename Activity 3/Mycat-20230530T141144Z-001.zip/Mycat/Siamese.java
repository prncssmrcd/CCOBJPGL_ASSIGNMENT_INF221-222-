package Mycat;

interface Siamese {

    String eyeColor = "blue";

    void bark();
}