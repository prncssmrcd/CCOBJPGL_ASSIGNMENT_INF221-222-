package Mycat;

interface MaineCoon {

    String mouth = "15 inches";

    
}