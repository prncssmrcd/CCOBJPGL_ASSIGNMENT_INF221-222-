package Mycat;

interface Siamaine extends MaineCoon , Siamese {

    void bark();
}