package Mycat;

public class Pet implements Siamaine {

    
    public void bark() {
        System.out.println("My cute Siamaine is meowing");
    };
}