package MyDog;
interface labrador{

    String bark = "Japan";

    void bark();
}