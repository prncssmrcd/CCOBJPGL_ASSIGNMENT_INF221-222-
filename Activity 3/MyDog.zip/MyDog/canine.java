package MyDog;
class canine{

    String mouth = "15 inches";

    
}