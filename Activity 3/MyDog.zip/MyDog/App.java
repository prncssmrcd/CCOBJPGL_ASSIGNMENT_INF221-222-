package MyDog;
public class App {
    public static void main(String[] args) throws Exception {

        // Create object from pet class
        cabrador myPet = new cabrador();

        myPet.bark();
        System.out.println(myPet.mouth);
        System.out.println(myPet.bark);
    }
}

