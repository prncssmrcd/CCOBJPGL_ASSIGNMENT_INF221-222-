package MyDog;

class cabrador extends canine implements labrador{


    public void bark(){
        System.out.println("My cabrador is barking");
    }
}